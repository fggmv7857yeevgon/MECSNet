import os
from PIL import Image
import torchvision.transforms as transforms
import sys
import argparse
import random

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from rcps_module import RCPSModule
from torch.cuda.amp import autocast, GradScaler
from torch.utils.tensorboard import SummaryWriter
from tqdm import tqdm
import logging
from pathlib import Path

# 导入你的模型
from networks.Me import RCPS_UNet
from cat_constraint import CATConstraint


# ============ 辅助函数 ============
def set_seed(seed=1337):
    """设置随机种子"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def get_logger(log_dir):
    """创建日志记录器"""
    logger = logging.getLogger('MeanTeacher')
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)

    fh = logging.FileHandler(os.path.join(log_dir, 'training.log'))
    fh.setLevel(logging.INFO)

    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    fh.setFormatter(formatter)
    ch.setFormatter(formatter)

    logger.addHandler(fh)
    logger.addHandler(ch)

    return logger


# ============ 损失函数 ============
class DiceLoss(nn.Module):
    """Dice Loss - 修复版"""

    def __init__(self, n_classes=2, smooth=1e-5):
        super().__init__()
        self.n_classes = n_classes
        self.smooth = smooth

    def forward(self, pred, target):
        # pred: [B, C, H, W], target: [B, H, W]
        pred_soft = F.softmax(pred, dim=1)

        # One-hot编码
        target_one_hot = F.one_hot(target.long(), self.n_classes)  # [B, H, W, C]
        target_one_hot = target_one_hot.permute(0, 3, 1, 2).float()  # [B, C, H, W]

        # 计算Dice
        intersection = (pred_soft * target_one_hot).sum(dim=(2, 3))
        union = pred_soft.sum(dim=(2, 3)) + target_one_hot.sum(dim=(2, 3))

        dice = (2.0 * intersection + self.smooth) / (union + self.smooth)

        # ✅ 确保损失非负
        dice_loss = 1.0 - dice.mean()
        dice_loss = torch.clamp(dice_loss, min=0.0, max=2.0)  # 防止负值

        return dice_loss


class FocalLoss(nn.Module):
    """Focal Loss - 处理类别不平衡"""

    def __init__(self, alpha=0.8, gamma=2.0):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma

    def forward(self, logits, labels):
        ce_loss = F.cross_entropy(logits, labels, reduction='none')
        pt = torch.exp(-ce_loss)
        alpha_t = torch.where(labels == 1, self.alpha, 1 - self.alpha)
        focal_loss = alpha_t * (1 - pt) ** self.gamma * ce_loss
        return focal_loss.mean()


class CombinedLoss(nn.Module):
    """组合损失 - 修复版"""

    def __init__(self, n_classes=2, ce_weight=0.3, dice_weight=0.5, focal_weight=0.2):
        super().__init__()
        # ✅ 正确保存类别权重
        self.register_buffer('class_weights', torch.tensor([1.0, 6.0]))
        self.ce = nn.CrossEntropyLoss(reduction='none')  # 改为none，手动应用权重
        self.dice = DiceLoss(n_classes)
        self.focal = FocalLoss(alpha=0.8, gamma=2.0)

        self.ce_weight = ce_weight
        self.dice_weight = dice_weight
        self.focal_weight = focal_weight

    def forward(self, pred, target):
        # ✅ 手动应用类别权重的CE损失
        ce_loss_per_pixel = self.ce(pred, target)  # [B, H, W]

        # 根据target的类别应用权重
        weight_map = torch.where(target == 1,
                                 self.class_weights[1],
                                 self.class_weights[0])
        ce_loss = (ce_loss_per_pixel * weight_map).mean()

        dice_loss = self.dice(pred, target)
        focal_loss = self.focal(pred, target)

        # 确保各项非负
        ce_loss = torch.clamp(ce_loss, min=0.0)
        dice_loss = torch.clamp(dice_loss, min=0.0)
        focal_loss = torch.clamp(focal_loss, min=0.0)

        total = self.ce_weight * ce_loss + self.dice_weight * dice_loss + self.focal_weight * focal_loss

        if not torch.isfinite(total) or total < 0:
            return torch.tensor(0.5, device=pred.device, requires_grad=True)

        return total


# ============ 权重调度 ============

def sigmoid_rampup(current, rampup_length):
    """Sigmoid ramp-up"""
    if rampup_length == 0:
        return 1.0
    current = np.clip(current, 0.0, rampup_length)
    phase = 1.0 - current / rampup_length
    return float(np.exp(-5.0 * phase * phase))


def update_ema_variables(model, ema_model, alpha, global_step):
    """更新EMA教师网络"""
    alpha = min(1 - 1 / (global_step + 1), alpha)
    for ema_param, param in zip(ema_model.parameters(), model.parameters()):
        ema_param.data.mul_(alpha).add_(param.data, alpha=1 - alpha)


# ============ 数据增强（修复版）============

# ImageNet归一化参数
IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)


def denormalize(image, device):
    """反归一化"""
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    return image * std + mean


def normalize(image, device):
    """归一化"""
    mean = IMAGENET_MEAN.to(device)
    std = IMAGENET_STD.to(device)
    return (image - mean) / std


def strong_augmentation(image):
    """
    强增强: 对归一化后的图像进行增强
    修复：正确处理归一化后的图像
    """
    device = image.device

    # 1. 反归一化到[0,1]范围
    image = denormalize(image, device)

    # 2. 水平翻转
    if random.random() > 0.5:
        image = torch.flip(image, dims=[-1])  # 修复：使用-1表示最后一个维度

    # 3. 垂直翻转
    if random.random() > 0.5:
        image = torch.flip(image, dims=[-2])  # 修复：使用-2表示倒数第二维度

    # 4. 颜色抖动（在[0,1]范围内）
    if random.random() > 0.5:
        # 亮度调整
        brightness_factor = random.uniform(0.8, 1.2)
        image = image * brightness_factor

        # 对比度调整
        if random.random() > 0.5:
            contrast_factor = random.uniform(0.8, 1.2)
            mean = image.mean(dim=[-2, -1], keepdim=True)
            image = (image - mean) * contrast_factor + mean

        # 裁剪到[0,1]
        image = torch.clamp(image, 0.0, 1.0)

    # 5. 高斯噪声（可选，增加鲁棒性）
    if random.random() > 0.7:
        noise = torch.randn_like(image) * 0.02
        image = torch.clamp(image + noise, 0.0, 1.0)

    # 6. 重新归一化
    image = normalize(image, device)

    return image


def weak_augmentation(image, mask=None):
    """弱增强: 仅水平翻转"""
    if random.random() > 0.5:
        image = torch.flip(image, dims=[-1])
        if mask is not None:
            mask = torch.flip(mask, dims=[-1])
    return image, mask


# ============ 评估指标 ============

def calculate_metrics_batch(pred, target, smooth=1e-5):
    """计算批次的分割指标"""
    pred = pred.float()
    target = target.float()

    pred_flat = pred.reshape(pred.size(0), -1)
    target_flat = target.reshape(target.size(0), -1)

    TP = (pred_flat * target_flat).sum(dim=1)
    TN = ((1 - pred_flat) * (1 - target_flat)).sum(dim=1)
    FP = (pred_flat * (1 - target_flat)).sum(dim=1)
    FN = ((1 - pred_flat) * target_flat).sum(dim=1)

    DSC = (2 * TP + smooth) / (2 * TP + FP + FN + smooth)
    Jaccard = (TP + smooth) / (TP + FP + FN + smooth)
    SEN = (TP + smooth) / (TP + FN + smooth)
    AC = (TP + TN + smooth) / (TP + TN + FP + FN + smooth)

    return {
        'DSC': DSC.mean().item(),
        'Jaccard': Jaccard.mean().item(),
        'SEN': SEN.mean().item(),
        'AC': AC.mean().item()
    }


# ============ 通用息肉数据集类 ============
class PolypDataset(Dataset):
    """通用息肉分割数据集 - 修复版"""

    def __init__(self, image_files, images_dir, masks_dir,
                 image_size=384, is_labeled=True, mask_suffix='.png',
                 use_augmentation=True):
        self.image_files = image_files
        self.images_dir = images_dir
        self.masks_dir = masks_dir
        self.image_size = image_size
        self.is_labeled = is_labeled
        self.mask_suffix = mask_suffix
        self.use_augmentation = use_augmentation

        # 基础变换（不包含随机增强）
        self.resize = transforms.Resize((image_size, image_size))
        self.to_tensor = transforms.ToTensor()
        self.normalize = transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std=[0.229, 0.224, 0.225]
        )

    def __len__(self):
        return len(self.image_files)

    def _get_mask_filename(self, image_filename):
        """根据图像文件名生成对应的mask文件名"""
        base_name = os.path.splitext(image_filename)[0]
        possible_names = [
            f"{base_name}{self.mask_suffix}",
            f"{base_name}_mask{self.mask_suffix}",
            f"p{base_name}{self.mask_suffix}",
            f"{base_name.replace('Original_', '')}{self.mask_suffix}",
        ]
        for mask_name in possible_names:
            mask_path = os.path.join(self.masks_dir, mask_name)
            if os.path.exists(mask_path):
                return mask_name
        return f"{base_name}{self.mask_suffix}"

    def __getitem__(self, idx):
        filename = self.image_files[idx]

        # 加载图像
        img_path = os.path.join(self.images_dir, filename)
        image = Image.open(img_path).convert('RGB')
        image = self.resize(image)

        if self.is_labeled:
            # 加载mask
            mask_filename = self._get_mask_filename(filename)
            mask_path = os.path.join(self.masks_dir, mask_filename)
            mask = Image.open(mask_path).convert('L')
            mask = self.resize(mask)

            # ✅ 同步数据增强
            if self.use_augmentation:
                # 随机水平翻转
                if random.random() > 0.5:
                    image = transforms.functional.hflip(image)
                    mask = transforms.functional.hflip(mask)

                # 随机垂直翻转
                if random.random() > 0.5:
                    image = transforms.functional.vflip(image)
                    mask = transforms.functional.vflip(mask)

                # 随机旋转（同一个角度）
                if random.random() > 0.5:
                    angle = random.uniform(-15, 15)
                    image = transforms.functional.rotate(image, angle)
                    mask = transforms.functional.rotate(mask, angle)

                # 颜色抖动（只对图像）
                if random.random() > 0.5:
                    image = transforms.ColorJitter(
                        brightness=0.2, contrast=0.2
                    )(image)

            # 转换为tensor
            image = self.to_tensor(image)
            image = self.normalize(image)
            mask = self.to_tensor(mask)
            mask = (mask > 0.5).float().squeeze(0)

            return image, mask
        else:
            # 无标签数据
            if self.use_augmentation:
                if random.random() > 0.5:
                    image = transforms.functional.hflip(image)
                if random.random() > 0.5:
                    image = transforms.functional.vflip(image)

            image = self.to_tensor(image)
            image = self.normalize(image)
            return image


# ============ 数据加载器创建 ============
def create_dataloaders(args, dataset_name):
    """创建数据加载器 - 修复版"""

    dataset_configs = {
        'kvasir': {'images_subdir': 'images', 'masks_subdir': 'masks', 'mask_suffix': '.jpg'},
        'clinic': {'images_subdir': 'images', 'masks_subdir': 'masks', 'mask_suffix': '.png'},
        'colon': {'images_subdir': 'images', 'masks_subdir': 'masks', 'mask_suffix': '.png'},
        'etis': {'images_subdir': 'images', 'masks_subdir': 'masks', 'mask_suffix': '.png'}
    }

    if dataset_name not in dataset_configs:
        raise ValueError(f"❌ 不支持的数据集: {dataset_name}")

    config = dataset_configs[dataset_name]

    # ✅ 删除旧的transform定义，改用Dataset内部处理

    name_map = {
        'kvasir': 'Kvasir-SEG', 'clinic': 'clinDB',
        'colon': 'CVC-ColonDB', 'etis': 'ETIS-LaribPolypDB'
    }
    dataset_root = os.path.join(args.data_root, name_map[dataset_name])
    images_dir = os.path.join(dataset_root, config['images_subdir'])
    masks_dir = os.path.join(dataset_root, config['masks_subdir'])

    if not os.path.exists(images_dir):
        raise ValueError(f"❌ 图像目录不存在: {images_dir}")

    image_files = sorted([
        f for f in os.listdir(images_dir)
        if f.lower().endswith(('.jpg', '.png', '.jpeg', '.bmp', '.tif'))
    ])

    print(f"✅ [{dataset_name.upper()}] 找到 {len(image_files)} 张图像")

    split_idx = int(len(image_files) * 0.8)
    train_files = image_files[:split_idx]
    val_files = image_files[split_idx:]

    labeled_ratio = args.labeled_ratio
    num_labeled = max(int(len(train_files) * labeled_ratio), 1)
    labeled_files = train_files[:num_labeled]
    unlabeled_files = train_files[num_labeled:]

    print(f"📊 [{dataset_name.upper()}] 有标签: {len(labeled_files)}, 无标签: {len(unlabeled_files)}, 验证: {len(val_files)}")

    # ✅ 使用修复后的Dataset
    labeled_dataset = PolypDataset(
        labeled_files, images_dir, masks_dir,
        image_size=args.patch_size,
        is_labeled=True,
        mask_suffix=config['mask_suffix'],
        use_augmentation=True  # 训练时使用增强
    )

    unlabeled_dataset = PolypDataset(
        unlabeled_files, images_dir, masks_dir,
        image_size=args.patch_size,
        is_labeled=False,
        mask_suffix=config['mask_suffix'],
        use_augmentation=True
    )

    val_dataset = PolypDataset(
        val_files, images_dir, masks_dir,
        image_size=args.patch_size,
        is_labeled=True,
        mask_suffix=config['mask_suffix'],
        use_augmentation=False  # 验证时不使用增强
    )

    labeled_loader = DataLoader(
        labeled_dataset, batch_size=args.labeled_bs,
        shuffle=True, num_workers=args.num_workers,
        pin_memory=True, drop_last=True
    )

    unlabeled_loader = DataLoader(
        unlabeled_dataset, batch_size=args.unlabeled_bs,
        shuffle=True, num_workers=args.num_workers,
        pin_memory=True, drop_last=True
    )

    val_loader = DataLoader(
        val_dataset, batch_size=args.labeled_bs,
        shuffle=False, num_workers=args.num_workers,
        pin_memory=True, drop_last=False
    )

    return labeled_loader, unlabeled_loader, val_loader


# ============ 主训练器（精简版）============

class MeanTeacherTrainer:
    """Mean Teacher训练器 - 精简版"""

    def __init__(self, args):
        self.args = args
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

        # 创建目录
        self.exp_dir = Path(args.exp_dir)
        self.exp_dir.mkdir(parents=True, exist_ok=True)
        self.checkpoint_dir = self.exp_dir / 'checkpoints'
        self.checkpoint_dir.mkdir(exist_ok=True)

        # 日志和TensorBoard
        self.logger = get_logger(str(self.exp_dir))
        self.writer = SummaryWriter(str(self.exp_dir / 'tensorboard'))

        # 创建模型
        self.student_model = RCPS_UNet(
            in_channels=args.in_channels,
            num_classes=args.num_classes
        ).to(self.device)

        self.teacher_model = RCPS_UNet(
            in_channels=args.in_channels,
            num_classes=args.num_classes
        ).to(self.device)

        # 初始化教师网络
        for param_t, param_s in zip(self.teacher_model.parameters(),
                                    self.student_model.parameters()):
            param_t.data.copy_(param_s.data)
            param_t.requires_grad = False

        # RCPS模块
        self.rcps_module = RCPSModule(
            temperature=args.rcps_temperature,
            kl_weight=args.rcps_kl_weight,
            contrast_temperature=args.contrast_temperature,
            contrast_sample_num=args.contrast_sample_num,
            consistency_type=args.consistency_type,
            buffer_size=args.buffer_size,
            min_buffer_size=getattr(args, 'min_buffer_size', 32)
        ).to(self.device)

        # CAT约束
        self.use_cat = args.use_cat
        if self.use_cat:
            self.cat_constraint = CATConstraint(
                num_classes=args.num_classes,
                feature_dim=None,
                alpha=args.cat_alpha,
                temperature=0.5,
                margin=1.0
            ).to(self.device)
        else:
            self.cat_constraint = None

        # 优化器
        self.optimizer = torch.optim.AdamW(
            list(self.student_model.parameters()) +
            list(self.rcps_module.parameters()),
            lr=args.learning_rate,
            weight_decay=args.weight_decay,
            betas=(0.9, 0.999)
        )

        # 学习率调度器
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingWarmRestarts(
            self.optimizer,
            T_0=args.T_0,
            T_mult=args.T_mult,
            eta_min=args.eta_min
        )

        # 混合精度
        self.scaler = GradScaler(enabled=args.use_amp)

        # 损失函数
        self.supervised_loss = CombinedLoss(
            n_classes=args.num_classes,
            ce_weight=0.5,
            dice_weight=0.5
        )

        # 训练状态
        self.global_step = 0
        self.best_dice = 0.0

        # 打印配置信息
        self._print_config()

    def _print_config(self):
        """打印配置信息"""
        self.logger.info("=" * 60)
        self.logger.info("Training Configuration:")
        self.logger.info(f"  Device: {self.device}")
        self.logger.info(f"  Student parameters: {sum(p.numel() for p in self.student_model.parameters()):,}")
        self.logger.info(f"  Learning rate: {self.args.learning_rate}")
        self.logger.info(f"  EMA start epoch: {self.args.ema_start_epoch}")
        self.logger.info(f"  EMA decay: {self.args.ema_decay}")
        self.logger.info(f"  RCPS weight: {self.args.rcps_weight}")
        self.logger.info(f"  RCPS temperature: {self.args.rcps_temperature}")
        self.logger.info(f"  CAT enabled: {self.use_cat}")
        if self.use_cat:
            self.logger.info(f"  CAT alpha: {self.args.cat_alpha}")
        self.logger.info("=" * 60)

    def train_epoch(self, labeled_loader, unlabeled_loader, epoch):
        """训练一个epoch - 精简版"""
        self.student_model.train()
        self.teacher_model.train()

        # 创建迭代器
        labeled_iter = iter(labeled_loader)
        unlabeled_iter = iter(unlabeled_loader)
        num_iterations = max(len(labeled_loader), len(unlabeled_loader))

        # 损失累计器
        epoch_losses = {
            'supervised': 0.0,
            'rcps': 0.0,
            'cat': 0.0,
            'total': 0.0
        }

        pbar = tqdm(range(num_iterations), desc=f'Epoch {epoch}')

        for iteration in pbar:
            # ========== 1. 获取批次数据 ==========
            try:
                labeled_batch = next(labeled_iter)
            except StopIteration:
                labeled_iter = iter(labeled_loader)
                labeled_batch = next(labeled_iter)

            try:
                unlabeled_batch = next(unlabeled_iter)
            except StopIteration:
                unlabeled_iter = iter(unlabeled_loader)
                unlabeled_batch = next(unlabeled_iter)

            # 解包数据
            if isinstance(unlabeled_batch, (tuple, list)):
                unlabeled_images = unlabeled_batch[0]
            else:
                unlabeled_images = unlabeled_batch

            labeled_images, labels = labeled_batch[0], labeled_batch[1]

            labeled_images = labeled_images.to(self.device)
            labels = labels.to(self.device).long()
            unlabeled_images = unlabeled_images.to(self.device)

            # ========== 2. 有标签数据训练 ==========
            with autocast(enabled=self.args.use_amp):
                # 学生网络预测
                student_outputs = self.student_model(labeled_images)
                if isinstance(student_outputs, dict):
                    student_logits = student_outputs['segmentation']
                    student_features = student_outputs.get('features', None)
                else:
                    student_logits = student_outputs
                    student_features = None

                # 监督损失
                supervised_loss = self.supervised_loss(student_logits, labels)

                # CAT约束损失
                cat_loss = torch.tensor(0.0, device=self.device)
                if self.use_cat and self.cat_constraint is not None:
                    if student_features is not None:
                        cat_loss, _, _ = self.cat_constraint(student_features, labels)
                    else:
                        # 如果模型没有返回features，使用logits作为替代
                        cat_loss, _, _ = self.cat_constraint(student_logits, labels)

            # ========== 3. 无标签数据半监督学习 ==========
            rcps_loss = torch.tensor(0.0, device=self.device)

            if epoch >= self.args.ema_start_epoch:
                # 强增强
                unlabeled_images_strong = strong_augmentation(unlabeled_images)

                with autocast(enabled=self.args.use_amp):
                    # 学生预测（强增强）
                    student_unlabeled_outputs = self.student_model(unlabeled_images_strong)
                    if isinstance(student_unlabeled_outputs, dict):
                        student_unlabeled_logits = student_unlabeled_outputs['segmentation']
                        student_unlabeled_features = student_unlabeled_outputs.get('features', None)
                    else:
                        student_unlabeled_logits = student_unlabeled_outputs
                        student_unlabeled_features = None

                    # 数值稳定性
                    student_unlabeled_logits = torch.clamp(student_unlabeled_logits, min=-50.0, max=50.0)
                # 教师预测（弱增强/原图）
                with torch.no_grad():
                    teacher_unlabeled_outputs = self.teacher_model(unlabeled_images)
                    if isinstance(teacher_unlabeled_outputs, dict):
                        teacher_logits = teacher_unlabeled_outputs['segmentation']
                    else:
                        teacher_logits = teacher_unlabeled_outputs

                    teacher_logits = torch.clamp(teacher_logits, min=-50.0, max=50.0)

                # RCPS损失（整合了对比学习+一致性损失）
                with autocast(enabled=self.args.use_amp):
                    student_outputs_for_rcps = {
                        'segmentation': student_unlabeled_logits,
                        'features': student_unlabeled_features
                    }

                    try:
                        unlabeled_losses = self.rcps_module.compute_unlabeled_loss(
                            student_outputs_for_rcps,
                            teacher_logits,
                            compute_consistency=True
                        )
                        rcps_base = unlabeled_losses.get('rcps_loss', 0.0)
                        contrastive = unlabeled_losses.get('contrastive_loss', 0.0)
                        consistency = unlabeled_losses.get('consistency_loss', 0.0)

                        if not torch.is_tensor(rcps_base):
                            rcps_base = torch.tensor(rcps_base, device=self.device)
                        if not torch.is_tensor(contrastive):
                            contrastive = torch.tensor(contrastive, device=self.device)
                        if not torch.is_tensor(consistency):
                            consistency = torch.tensor(consistency, device=self.device)

                        rcps_loss = rcps_base + 0.3 * contrastive + 0.3 * consistency

                        rcps_loss = torch.clamp(rcps_loss, min=0.0, max=1.0)

                        if not torch.isfinite(rcps_loss):
                            rcps_loss = torch.tensor(0.0, device=self.device)

                    except Exception as e:
                        self.logger.warning(f"RCPS computation failed: {e}")
                        rcps_loss = torch.tensor(0.0, device=self.device)

            # ========== 4. 总损失（精简为3个核心损失）==========
            with autocast(enabled=self.args.use_amp):
                # 动态权重调度
                if epoch < self.args.ema_start_epoch:
                    # 预热阶段：只用监督损失 + CAT
                    rcps_weight = 0.0
                else:
                    progress = (epoch - self.args.ema_start_epoch) / max(
                        self.args.max_epochs - self.args.ema_start_epoch, 1)
                    # ✅ 更保守的权重增长
                    rcps_weight = self.args.rcps_weight * min(progress, 0.3)
                if torch.is_tensor(rcps_loss) and rcps_loss.item() > 1.0:
                    rcps_weight = rcps_weight * 0.1
                cat_weight = self.args.cat_alpha if self.use_cat else 0.0
                total_loss = (
                        supervised_loss +
                        rcps_weight * rcps_loss +
                        cat_weight * cat_loss
                )

            # 检查损失有效性
            if not torch.isfinite(total_loss):
                self.logger.warning(f"Invalid loss at epoch {epoch}, iter {iteration}, skipping...")
                continue

            # ========== 5. 反向传播 ==========
            self.optimizer.zero_grad()
            self.scaler.scale(total_loss).backward()

            # 梯度裁剪
            self.scaler.unscale_(self.optimizer)
            torch.nn.utils.clip_grad_norm_(
                list(self.student_model.parameters()) + list(self.rcps_module.parameters()),
                max_norm=1.0
            )

            self.scaler.step(self.optimizer)
            self.scaler.update()

            # ========== 6. 更新教师网络（EMA）==========
            if epoch >= self.args.ema_start_epoch:
                update_ema_variables(
                    self.student_model,
                    self.teacher_model,
                    self.args.ema_decay,
                    self.global_step
                )

            # ========== 7. 记录损失 ==========
            epoch_losses['supervised'] += supervised_loss.item()
            epoch_losses['rcps'] += rcps_loss.item() if torch.is_tensor(rcps_loss) else rcps_loss
            epoch_losses['cat'] += cat_loss.item() if torch.is_tensor(cat_loss) else cat_loss
            epoch_losses['total'] += total_loss.item()

            self.global_step += 1

            # 更新进度条
            pbar.set_postfix({
                'sup': f'{supervised_loss.item():.4f}',
                'rcps': f'{rcps_loss.item() if torch.is_tensor(rcps_loss) else 0:.4f}',
                'cat': f'{cat_loss.item() if torch.is_tensor(cat_loss) else 0:.4f}',
                'total': f'{total_loss.item():.4f}'
            })

            # TensorBoard记录
            if iteration % 50 == 0:
                self.writer.add_scalar('train/supervised_loss', supervised_loss.item(), self.global_step)
                self.writer.add_scalar('train/rcps_loss',
                                       rcps_loss.item() if torch.is_tensor(rcps_loss) else 0,
                                       self.global_step)
                self.writer.add_scalar('train/cat_loss',
                                       cat_loss.item() if torch.is_tensor(cat_loss) else 0,
                                       self.global_step)
                self.writer.add_scalar('train/total_loss', total_loss.item(), self.global_step)
                self.writer.add_scalar('train/lr', self.optimizer.param_groups[0]['lr'], self.global_step)
                self.writer.add_scalar('train/rcps_weight', rcps_weight, self.global_step)

        # ========== 8. Epoch统计 ==========
        num_iterations = max(num_iterations, 1)
        avg_losses = {k: v / num_iterations for k, v in epoch_losses.items()}

        self.logger.info(
            f'Epoch {epoch} - '
            f'Sup: {avg_losses["supervised"]:.4f}, '
            f'RCPS: {avg_losses["rcps"]:.4f}, '
            f'CAT: {avg_losses["cat"]:.4f}, '
            f'Total: {avg_losses["total"]:.4f}'
        )

        # 更新学习率
        self.scheduler.step()
        return avg_losses

    @torch.no_grad()
    def validate(self, val_loader, epoch):
        """验证 - 修复版"""
        # ✅ EMA开始前用学生模型
        if epoch < self.args.ema_start_epoch:
            model = self.student_model
        else:
            model = self.teacher_model

        model.eval()

        metrics_accumulator = {'DSC': [], 'Jaccard': [], 'SEN': [], 'AC': []}
        total_pred_fg = 0
        total_label_fg = 0
        total_pixels = 0

        for images, labels in tqdm(val_loader, desc='Validating', leave=False):
            images = images.to(self.device)
            labels = labels.to(self.device).long()

            with autocast(enabled=self.args.use_amp):
                outputs = model(images)  # ✅ 用 model 而不是 self.teacher_model
                if isinstance(outputs, dict):
                    logits = outputs['segmentation']
                else:
                    logits = outputs

            preds = torch.argmax(logits, dim=1).float()
            labels_float = labels.float()

            batch_pixels = preds.numel()
            total_pred_fg += (preds == 1).sum().item()
            total_label_fg += (labels == 1).sum().item()
            total_pixels += batch_pixels

            batch_metrics = calculate_metrics_batch(preds, labels_float)
            for key in metrics_accumulator.keys():
                metrics_accumulator[key].append(batch_metrics[key])

        avg_metrics = {key: np.mean(values) if values else 0.0
                       for key, values in metrics_accumulator.items()}

        pred_fg_ratio = total_pred_fg / max(total_pixels, 1)
        label_fg_ratio = total_label_fg / max(total_pixels, 1)

        self.logger.info(
            f'Epoch {epoch} - Validation Metrics:\n'
            f'  DSC (Dice):     {avg_metrics["DSC"]:.4f}\n'
            f'  Jaccard (IoU):  {avg_metrics["Jaccard"]:.4f}\n'
            f'  SEN (Recall):   {avg_metrics["SEN"]:.4f}\n'
            f'  AC (Accuracy):  {avg_metrics["AC"]:.4f}'
            f'  [DEBUG] Pred FG ratio:  {pred_fg_ratio:.4f}\n'
            f'  [DEBUG] Label FG ratio: {label_fg_ratio:.4f}'
        )

        if pred_fg_ratio < 0.01 and label_fg_ratio > 0.05:
            self.logger.warning("⚠️ Model predicts almost all background!")

        for key, value in avg_metrics.items():
            self.writer.add_scalar(f'val/{key}', value, epoch)

        if avg_metrics['DSC'] > self.best_dice:
            self.best_dice = avg_metrics['DSC']
            self.save_checkpoint(epoch, is_best=True)
            self.logger.info(f'✅ New best model saved! DSC: {avg_metrics["DSC"]:.4f}')

        return avg_metrics

    def save_checkpoint(self, epoch, is_best=False):
        """保存检查点"""
        checkpoint = {
            'epoch': epoch,
            'global_step': self.global_step,
            'student_state_dict': self.student_model.state_dict(),
            'teacher_state_dict': self.teacher_model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'best_dice': self.best_dice,
            'args': vars(self.args)
        }

        if is_best:
            torch.save(checkpoint, self.checkpoint_dir / 'best_model.pth')
        else:
            torch.save(checkpoint, self.checkpoint_dir / f'checkpoint_epoch_{epoch}.pth')

    def load_checkpoint(self, checkpoint_path):
        """加载检查点"""
        checkpoint = torch.load(checkpoint_path, map_location=self.device)
        self.student_model.load_state_dict(checkpoint['student_state_dict'])
        self.teacher_model.load_state_dict(checkpoint['teacher_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        self.global_step = checkpoint['global_step']
        self.best_dice = checkpoint['best_dice']
        return checkpoint['epoch']

    def train(self, labeled_loader, unlabeled_loader, val_loader):
        """完整训练流程"""
        self.logger.info("=" * 60)
        self.logger.info("Starting training...")
        self.logger.info("=" * 60)

        for epoch in range(1, self.args.max_epochs + 1):
            # 训练
            self.train_epoch(labeled_loader, unlabeled_loader, epoch)

            # 验证
            if epoch % self.args.eval_interval == 0:
                self.validate(val_loader, epoch)

            # 保存检查点
            if epoch % self.args.save_interval == 0:
                self.save_checkpoint(epoch)

        self.logger.info("=" * 60)
        self.logger.info(f"Training completed! Best Dice: {self.best_dice:.4f}")
        self.logger.info("=" * 60)
        self.writer.close()

        return self.best_dice


# ============ 参数解析（修复版）============

def parse_args():
    """解析命令行参数 - 优化版"""
    parser = argparse.ArgumentParser(description='Mean Teacher Semi-Supervised Segmentation')

    # ========== 实验设置 ==========
    parser.add_argument('--exp_dir', type=str, default='./experiments/mean_teacher')
    parser.add_argument('--seed', type=int, default=1337)

    # ========== 数据设置 ==========
    parser.add_argument('--data_root', type=str, default='/root/autodl-tmp/data')
    parser.add_argument('--patch_size', type=int, default=384)
    parser.add_argument('--labeled_bs', type=int, default=8)
    parser.add_argument('--unlabeled_bs', type=int, default=8)
    parser.add_argument('--num_workers', type=int, default=4)
    parser.add_argument('--in_channels', type=int, default=3)
    parser.add_argument('--num_classes', type=int, default=2)
    parser.add_argument('--labeled_ratio', type=float, default=0.2)

    # ========== 训练设置 ==========
    parser.add_argument('--max_epochs', type=int, default=150)
    parser.add_argument('--learning_rate', type=float, default=5e-4)  # ✅ OK
    parser.add_argument('--weight_decay', type=float, default=1e-4)
    parser.add_argument('--eval_interval', type=int, default=5)
    parser.add_argument('--save_interval', type=int, default=10)

    # ========== 学习率调度 ==========
    parser.add_argument('--T_0', type=int, default=15)  # 🔄 增加一点
    parser.add_argument('--T_mult', type=int, default=2)
    parser.add_argument('--eta_min', type=float, default=1e-6)

    # ========== Mean Teacher ==========
    parser.add_argument('--ema_decay', type=float, default=0.99)  # ✅ OK
    parser.add_argument('--ema_start_epoch', type=int, default=15)  # 🔄 改为15，不要太晚

    # ========== RCPS模块 ==========
    parser.add_argument('--rcps_weight', type=float, default=0.3)  # 🔄 稍微提高，因为模块内部已经裁剪
    parser.add_argument('--rcps_temperature', type=float, default=1.0)  # ✅ OK
    parser.add_argument('--rcps_kl_weight', type=float, default=0.1)  # ✅ OK
    parser.add_argument('--contrast_temperature', type=float, default=0.2)  # 🔄 降低，对比更强
    parser.add_argument('--contrast_sample_num', type=int, default=256)  # ✅ OK
    parser.add_argument('--consistency_type', type=str, default='mse')  # ✅ OK
    parser.add_argument('--buffer_size', type=int, default=256)  # ✅ 添加这个
    parser.add_argument('--min_buffer_size', type=int, default=32)  # ✅ 添加这个

    # ========== CAT约束 ==========
    parser.add_argument('--use_cat', action='store_true', default=True)
    parser.add_argument('--cat_alpha', type=float, default=0.1)  # ✅ OK

    # ========== 混合精度 ==========
    parser.add_argument('--use_amp', action='store_true', default=True)

    args = parser.parse_args()
    return args


# ============ 主函数 ============

def main():
    """主函数"""
    args = parse_args()

    # 设置随机种子
    set_seed(args.seed)

    # 打印参数
    print("=" * 80)
    print("🔧 训练参数配置:")
    print("=" * 80)
    for key, value in vars(args).items():
        print(f"  {key}: {value}")
    print("=" * 80 + "\n")

    # 要训练的数据集列表
    datasets_to_train = ['kvasir', 'clinic', 'colon', 'etis']

    # 存储每个数据集的最佳结果
    results = {}

    print("=" * 80)
    print(f"🚀 开始训练 {len(datasets_to_train)} 个数据集 (精简版)")
    print(f"   核心模块: Mean Teacher + RCPS + CAT")
    print("=" * 80 + "\n")

    # 循环训练每个数据集
    for dataset_name in datasets_to_train:
        print(f"\n{'=' * 80}")
        print(f"📂 开始训练数据集: {dataset_name.upper()}")
        print(f"{'=' * 80}\n")

        # 创建数据加载器
        try:
            labeled_loader, unlabeled_loader, val_loader = create_dataloaders(args, dataset_name)
        except Exception as e:
            print(f"❌ [{dataset_name.upper()}] 数据加载失败: {e}")
            import traceback
            traceback.print_exc()
            continue

        # 修改实验目录
        original_exp_dir = args.exp_dir
        args.exp_dir = os.path.join(original_exp_dir, dataset_name.upper())

        # 创建训练器
        trainer = None
        try:
            trainer = MeanTeacherTrainer(args)
        except Exception as e:
            print(f"❌ [{dataset_name.upper()}] 训练器初始化失败: {e}")
            import traceback
            traceback.print_exc()
            args.exp_dir = original_exp_dir
            continue

        # 开始训练
        try:
            best_dice = trainer.train(labeled_loader, unlabeled_loader, val_loader)
            results[dataset_name] = best_dice
            print(f"\n✅ [{dataset_name.upper()}] 训练完成! Best Dice: {best_dice:.4f}\n")
        except Exception as e:
            print(f"❌ [{dataset_name.upper()}] 训练过程出错: {e}")
            import traceback
            traceback.print_exc()
        finally:
            args.exp_dir = original_exp_dir
            if trainer is not None and hasattr(trainer, 'writer'):
                trainer.writer.close()
            # 清理显存
            del trainer
            torch.cuda.empty_cache()

    # 打印总结
    print("\n" + "=" * 80)
    print("🎉 所有数据集训练完成!")
    print("=" * 80)
    print("\n📊 训练结果汇总:")
    print("-" * 40)
    for dataset_name, dice in results.items():
        print(f"  {dataset_name.upper():15s}: Dice = {dice:.4f}")
    if results:
        avg_dice = np.mean(list(results.values()))
        print("-" * 40)
        print(f"  {'Average':15s}: Dice = {avg_dice:.4f}")
    print("=" * 80)


if __name__ == '__main__':
    main()

