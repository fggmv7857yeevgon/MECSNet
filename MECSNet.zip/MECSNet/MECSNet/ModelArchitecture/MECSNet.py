import tensorflow as tf
from keras.layers import Conv2D, UpSampling2D
from keras.layers import add
from keras.models import Model
from keras_cv_attention_models import caformer
from CustomLayers.RAPU_blocks import resnet_block, RAPU, convf_bn_act, SBA
from tensorflow.keras.layers import Concatenate
from tensorflow.keras import models
from tensorflow.keras import layers

kernel_initializer = 'he_uniform'
interpolation = "nearest"
class Tongdao(tf.keras.layers.Layer):  # 处理通道部分
    def __init__(self, in_channel):
        super(Tongdao, self).__init__()
        self.avg_pool = layers.GlobalAveragePooling2D()  # 全局平均池化
        self.fc = layers.Conv2D(1, kernel_size=1, use_bias=False)  # 1x1卷积
        self.relu = layers.ReLU()  # ReLU激活函数

    def call(self, x):
        y = self.avg_pool(x)  # 应用全局平均池化
        y = tf.expand_dims(tf.expand_dims(y, 1), 1)  # 添加额外的维度，使其符合 [b, h, w, c]
        y = self.fc(y)  # 应用1x1卷积
        y = self.relu(y)  # 应用ReLU激活
        return x * y  # 通道重标定
class Kongjian(tf.keras.layers.Layer):  # 空间模块
    def __init__(self, in_channel):
        super(Kongjian, self).__init__()
        self.Conv1x1 = layers.Conv2D(1, kernel_size=1, use_bias=False)  # 1x1卷积
        self.norm = layers.Activation('sigmoid')  # Sigmoid激活

    def call(self, x):
        y = self.Conv1x1(x)  # 通过卷积
        y = self.norm(y)  # 应用Sigmoid激活
        return x * y  # 空间特征重标定

class Hebing(tf.keras.layers.Layer):  # 合并模块
    def __init__(self, in_channel):
        super(Hebing, self).__init__()
        self.tongdao = Tongdao(in_channel)  # 创建通道模块
        self.kongjian = Kongjian(in_channel)  # 创建空间模块

    def call(self, U):
        U_kongjian = self.kongjian(U)  # 空间模块输出
        U_tongdao = self.tongdao(U)  # 通道模块输出
        return tf.maximum(U_tongdao, U_kongjian)  # 合并两个模块的输出

class MDFA(tf.keras.layers.Layer):
    def __init__(self, dim_in, dim_out, rate=1, bn_mom=0.1):
        super(MDFA, self).__init__()
        self.branch1 = models.Sequential([
            layers.Conv2D(dim_out, 1, padding='same', dilation_rate=rate, use_bias=True),
            layers.BatchNormalization(momentum=bn_mom),
            layers.ReLU(),
        ])
        self.branch2 = models.Sequential([
            layers.Conv2D(dim_out, 3, padding='same', dilation_rate=6 * rate, use_bias=True),
            layers.BatchNormalization(momentum=bn_mom),
            layers.ReLU(),
        ])
        self.branch3 = models.Sequential([
            layers.Conv2D(dim_out, 3, padding='same', dilation_rate=12 * rate, use_bias=True),
            layers.BatchNormalization(momentum=bn_mom),
            layers.ReLU(),
        ])
        self.branch4 = models.Sequential([
            layers.Conv2D(dim_out, 3, padding='same', dilation_rate=18 * rate, use_bias=True),
            layers.BatchNormalization(momentum=bn_mom),
            layers.ReLU(),
        ])
        self.branch5_conv = layers.Conv2D(dim_out, 1, padding='valid', use_bias=True)
        self.branch5_bn = layers.BatchNormalization(momentum=bn_mom)
        self.branch5_relu = layers.ReLU()

        self.conv_cat = models.Sequential([
            layers.Conv2D(dim_out, 1, padding='same', use_bias=True),
            layers.BatchNormalization(momentum=bn_mom),
            layers.ReLU(),
        ])
        self.Hebing = Hebing(in_channel=dim_out * 5)

    def call(self, x):
        # Using tf.shape() to get dynamic shape
        shape = tf.shape(x)  # Get dynamic shape of input tensor
        b, row, col = shape[0], shape[1], shape[2]  # Get batch size, row, and column dimensions

        conv1x1 = self.branch1(x)
        conv3x3_1 = self.branch2(x)
        conv3x3_2 = self.branch3(x)
        conv3x3_3 = self.branch4(x)

        global_feature = tf.reduce_mean(x, axis=[1, 2], keepdims=True)
        global_feature = self.branch5_conv(global_feature)
        global_feature = self.branch5_bn(global_feature)
        global_feature = self.branch5_relu(global_feature)
        global_feature = tf.image.resize(global_feature, (row, col))  # Resize to match input dimensions

        # Ensure global_feature has the same shape as the other branches for concatenation
        global_feature = tf.reshape(global_feature, [b, row, col, conv1x1.shape[-1]])

        feature_cat = tf.concat([conv1x1, conv3x3_1, conv3x3_2, conv3x3_3, global_feature], axis=-1)

        larry = self.Hebing(feature_cat)
        larry_feature_cat = larry * feature_cat

        result = self.conv_cat(larry_feature_cat)

        return result

def create_model(img_height, img_width, input_chanels, out_classes, starting_filters):
    # 设置 pretrained=None 以避免下载预训练权重
    backbone = caformer.CAFormerS18(input_shape=(352, 352, 3), pretrained=None, num_classes=0)

# 手动加载下载的预训练权重
    backbone.load_weights('/root/autodl-tmp/RAPUNet-main/caformer_s18_384_imagenet.h5', by_name=True, skip_mismatch=True)


    layer_names = ['stack4_block3_mlp_Dense_1', 'stack3_block9_mlp_Dense_1', 'stack2_block3_mlp_Dense_1', 'stack1_block3_mlp_Dense_1']
    layers =[backbone.get_layer(x).output for x in layer_names]
    
    input_layer = backbone.input
    print('Starting RAPUNet')

    p1 = Conv2D(starting_filters * 2, 3, strides=2, padding='same')(input_layer)  
    p2 = Conv2D(starting_filters*4, 1, padding='same')(layers[3]) #88,88
    p3 = Conv2D(starting_filters*8, 1, padding='same')(layers[2]) #44,44
    p4 = Conv2D(starting_filters*16, 1, padding='same')(layers[1]) #22,22     
    p5 = Conv2D(starting_filters*32, 1, padding='same')(layers[0]) #11,11
    
    t0 = RAPU(input_layer, starting_filters)  #352, 352

    l1i = Conv2D(starting_filters * 2, 2, strides=2, padding='same')(t0)    
    s1 = add([l1i, p1])     
    t1 = RAPU(s1, starting_filters * 2)  #176,176      

    # Add MDFA after RAPU
    t1 = MDFA(dim_in=starting_filters*2, dim_out=starting_filters*2)(t1)  # Apply MDFA to enhance features

    l2i = Conv2D(starting_filters * 4, 2, strides=2, padding='same')(t1)
    s2 = add([l2i, p2])
    t2 = RAPU(s2, starting_filters * 4) #88,88

    # Add MDFA after RAPU
    t2 = MDFA(dim_in=starting_filters*4, dim_out=starting_filters*4)(t2)  # Apply MDFA to enhance features

    l3i = Conv2D(starting_filters * 8, 2, strides=2, padding='same')(t2)
    s3 = add([l3i, p3])
    t3 = RAPU(s3, starting_filters * 8) #44,44

    # Add MDFA after RAPU
    t3 = MDFA(dim_in=starting_filters*8, dim_out=starting_filters*8)(t3)  # Apply MDFA to enhance features

    l4i = Conv2D(starting_filters * 16, 2, strides=2, padding='same')(t3)
    s4 = add([l4i, p4])
    t4 = RAPU(s4, starting_filters * 16) #22,22
    
    # Add MDFA after RAPU
    t4 = MDFA(dim_in=starting_filters*16, dim_out=starting_filters*16)(t4)  # Apply MDFA to enhance features
    
    l5i = Conv2D(starting_filters * 32, 2, strides=2, padding='same')(t4)
    s5 = add([l5i, p5]) 
    
    t51 = resnet_block(s5, starting_filters*32)
    t51 = resnet_block(t51, starting_filters*32) 
    t53 = resnet_block(t51, starting_filters*16) #11,11
    t53 = resnet_block(t53, starting_filters*16) #11,11

    #Aggregation
    dim =32
    
    outd = Concatenate(axis=-1)([UpSampling2D((4,4))(t53), UpSampling2D((2,2))(t4)])
    outd = Concatenate(axis=-1)([outd, t3]) #44,44 
    outd = convf_bn_act(outd, dim, 1)
    outd = Conv2D(1, kernel_size=1, use_bias=False)(outd)  #output1 44,44,1
    
    L_input = convf_bn_act(t2, dim, 3) #88,88,32   
    
    H_input = Concatenate(axis=-1)([UpSampling2D((2,2))(t53), t4])
    H_input = convf_bn_act(H_input, dim, 1)
    H_input = UpSampling2D((2,2))(H_input)  #44,44,32
    
    out2 = SBA(L_input, H_input) #output 88,88,1   
    
    out1 = UpSampling2D(size=(8,8), interpolation='bilinear')(outd)
    out2 = UpSampling2D(size=(4,4), interpolation='bilinear')(out2)
        
    out_duat = out1 + out2 
    output = Conv2D(out_classes, (1, 1), activation='sigmoid')(out_duat)
    
    model = Model(inputs=input_layer, outputs=output)

    return model

