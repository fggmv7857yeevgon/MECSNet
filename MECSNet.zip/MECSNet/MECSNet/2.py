import torch
import torch.nn as nn
import torch.nn.functional as F


class TensorBuffer:
    """特征缓冲区 - 用于对比学习的负样本存储"""

    def __init__(self, buffer_size=256):
        self.buffer = []
        self.buffer_size = buffer_size

    def update(self, features):
        """更新缓冲区"""
        features = features.detach()
        if len(self.buffer) < self.buffer_size:
            self.buffer.append(features)
        else:
            self.buffer.pop(0)
            self.buffer.append(features)

    def get_buffer(self):
        """获取缓冲区所有特征"""
        if len(self.buffer) == 0:
            return None
        return torch.cat(self.buffer, dim=0)

    def clear(self):
        """清空缓冲区"""
        self.buffer = []

    def __len__(self):
        return sum([f.size(0) for f in self.buffer])


class PixelContrastiveLoss(nn.Module):
    """像素级对比学习损失"""

    def __init__(self, temperature=0.1, sample_num=512, bidirectional=True):
        super().__init__()
        self.temperature = max(temperature, 0.1)
        self.sample_num = sample_num
        self.bidirectional = bidirectional

    def forward(self, features, labels, negative_buffer=None):
        B, C, H, W = features.shape

        if torch.isnan(features).any() or torch.isinf(features).any():
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        features = features.permute(0, 2, 3, 1).contiguous().view(-1, C)
        features = F.normalize(features, p=2, dim=1)

        labels = labels.view(-1)
        fg_mask = labels == 1
        fg_features = features[fg_mask]

        if fg_features.size(0) < 4:
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        num_samples = min(self.sample_num, fg_features.size(0) // 2)
        if num_samples < 2:
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        indices = torch.randperm(fg_features.size(0), device=features.device)[:num_samples * 2]
        anchor_features = fg_features[indices[:num_samples]]
        positive_features = fg_features[indices[num_samples:]]

        pos_sim = torch.sum(anchor_features * positive_features, dim=1)
        pos_sim = torch.clamp(pos_sim, min=-1.0, max=1.0)
        pos_logits = pos_sim / self.temperature

        if negative_buffer is not None and negative_buffer.size(0) > 0:
            neg_sample_num = min(negative_buffer.size(0), 256)
            neg_indices = torch.randperm(negative_buffer.size(0), device=features.device)[:neg_sample_num]
            neg_samples = negative_buffer[neg_indices]
            neg_samples = F.normalize(neg_samples, p=2, dim=1)

            neg_sim = torch.mm(anchor_features, neg_samples.t())
            neg_sim = torch.clamp(neg_sim, min=-1.0, max=1.0)
            neg_logits = neg_sim / self.temperature

            logits = torch.cat([pos_logits.unsqueeze(1), neg_logits], dim=1)
            logits = logits - logits.max(dim=1, keepdim=True)[0].detach()
            labels_contrast = torch.zeros(num_samples, dtype=torch.long, device=features.device)
            contrastive_loss = F.cross_entropy(logits, labels_contrast)
        else:
            contrastive_loss = (1.0 - pos_sim).mean() * 0.5

        if not torch.isfinite(contrastive_loss):
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        # ✅ 修改：降低最大值到0.5
        return torch.clamp(contrastive_loss, min=0.0, max=1.0)


class RectifiedPseudoSupervision(nn.Module):
    """校正的伪监督损失"""

    def __init__(self, temperature=1.0, kl_weight=0.1):
        super().__init__()
        self.temperature = max(temperature, 0.5)
        self.kl_weight = kl_weight

    def forward(self, student_logits, teacher_logits, confidence_threshold=0.5):
        if torch.isnan(student_logits).any() or torch.isnan(teacher_logits).any():
            return torch.tensor(0.0, device=student_logits.device, requires_grad=True)

        student_logits = torch.clamp(student_logits, min=-20.0, max=20.0)
        teacher_logits = torch.clamp(teacher_logits, min=-20.0, max=20.0)

        with torch.no_grad():
            teacher_probs = F.softmax(teacher_logits / self.temperature, dim=1)
            teacher_probs = torch.clamp(teacher_probs, min=1e-6, max=1.0)
            max_probs, _ = teacher_probs.max(dim=1)
            confidence_mask = (max_probs > confidence_threshold).float()

        log_student = F.log_softmax(student_logits, dim=1)
        ce_loss = -torch.sum(teacher_probs * log_student, dim=1)
        ce_loss = torch.clamp(ce_loss, min=0.0, max=5.0)

        if confidence_mask.sum() > 0:
            masked_ce_loss = (ce_loss * confidence_mask).sum() / (confidence_mask.sum() + 1e-6)
        else:
            masked_ce_loss = ce_loss.mean() * 0.1

        if self.kl_weight > 0:
            student_probs = F.softmax(student_logits, dim=1)
            kl_reg = F.mse_loss(student_probs, teacher_probs.detach())
            kl_reg = torch.clamp(kl_reg, max=0.5)  # ✅ 修改：降低到0.5
        else:
            kl_reg = 0.0

        total_loss = masked_ce_loss + self.kl_weight * kl_reg

        # ✅ 保持0.5的裁剪
        total_loss = torch.clamp(total_loss, min=0.0, max=1.0)

        if not torch.isfinite(total_loss):
            return torch.tensor(0.0, device=student_logits.device, requires_grad=True)

        return total_loss


class ConsistencyRegularization(nn.Module):
    """一致性正则化损失"""

    def __init__(self, consistency_type='mse'):
        super().__init__()
        self.consistency_type = consistency_type

    def forward(self, pred1, pred2, mask=None):
        if self.consistency_type == 'mse':
            prob1 = F.softmax(pred1, dim=1)
            prob2 = F.softmax(pred2, dim=1).detach()
            loss = F.mse_loss(prob1, prob2, reduction='none').mean(dim=1)

        elif self.consistency_type == 'kl':
            log_prob1 = F.log_softmax(pred1, dim=1)
            prob2 = F.softmax(pred2, dim=1).detach()
            loss = F.kl_div(log_prob1, prob2, reduction='none').sum(dim=1)
            loss = torch.clamp(loss, max=2.0)

        else:
            raise ValueError(f"Unknown consistency type: {self.consistency_type}")

        if mask is not None and mask.sum() > 0:
            result = (loss * mask).sum() / (mask.sum() + 1e-6)
        else:
            result = loss.mean()

        # ✅ 添加：最终裁剪
        return torch.clamp(result, min=0.0, max=1.0)


class RCPSModule(nn.Module):
    """RCPS模块 - 修复版"""

    def __init__(
            self,
            temperature=1.0,
            kl_weight=0.1,
            contrast_temperature=0.2,
            contrast_sample_num=256,  # ✅ 减少采样数
            consistency_type='mse',
            buffer_size=256,
            min_buffer_size=32
    ):
        super().__init__()

        self.rcps_loss = RectifiedPseudoSupervision(temperature, kl_weight)
        self.contrastive_loss = PixelContrastiveLoss(
            contrast_temperature,
            contrast_sample_num
        )
        self.consistency_loss = ConsistencyRegularization(consistency_type)

        self.negative_buffer_labeled = TensorBuffer(buffer_size)
        self.negative_buffer_unlabeled = TensorBuffer(buffer_size)
        self.min_buffer_size = min_buffer_size
        self.confidence_threshold = 0.5

    def resize_mask(self, mask, target_hw):
        if mask.shape[1:] != target_hw:
            mask = F.interpolate(
                mask.unsqueeze(1).float(),
                size=target_hw,
                mode="nearest"
            ).squeeze(1).long()
        return mask

    def compute_labeled_loss(self, student_outputs, labels):
        features = student_outputs.get("features")
        if features is None:
            return torch.tensor(0.0, device=labels.device, requires_grad=True)

        B, C, Hf, Wf = features.shape

        if torch.isnan(features).any() or torch.isinf(features).any():
            return torch.tensor(0.0, device=features.device, requires_grad=True)

        features = F.normalize(features, p=2, dim=1)
        labels_resized = self.resize_mask(labels, (Hf, Wf))

        bg_mask = (labels_resized == 0)
        if bg_mask.sum() > 0:
            feat_flat = features.permute(0, 2, 3, 1).reshape(-1, C)
            mask_flat = bg_mask.view(-1).bool()
            bg_features = feat_flat[mask_flat]

            if bg_features.size(0) > 256:
                indices = torch.randperm(bg_features.size(0), device=features.device)[:256]
                bg_features = bg_features[indices]

            if not torch.isnan(bg_features).any():
                self.negative_buffer_labeled.update(bg_features)

        buffer = self.negative_buffer_labeled.get_buffer()
        if buffer is not None and len(self.negative_buffer_labeled) >= self.min_buffer_size:
            contrastive_loss = self.contrastive_loss(features, labels_resized, buffer)
        else:
            contrastive_loss = self.contrastive_loss(features, labels_resized, None)

        # ✅ 添加：确保返回值被裁剪
        return torch.clamp(contrastive_loss, min=0.0, max=0.5)

    def compute_unlabeled_loss(self, student_outputs, teacher_logits,
                               compute_consistency=True, student_logits_weak=None):
        device = teacher_logits.device

        student_logits = student_outputs.get("segmentation")
        features = student_outputs.get("features")

        default_return = {
            "rcps_loss": torch.tensor(0.0, device=device, requires_grad=True),
            "contrastive_loss": torch.tensor(0.0, device=device, requires_grad=True),
            "consistency_loss": torch.tensor(0.0, device=device, requires_grad=True)
        }

        if student_logits is None:
            return default_return

        # ========== 1. RCPS损失 ==========
        rcps_loss = self.rcps_loss(student_logits, teacher_logits, self.confidence_threshold)
        rcps_loss = torch.clamp(rcps_loss, min=0.0, max=1.0)  # ✅ 确保裁剪

        # ========== 2. 对比损失 ==========
        contrastive_loss = torch.tensor(0.0, device=device, requires_grad=True)

        if features is not None:
            B, C, Hf, Wf = features.shape

            if not (torch.isnan(features).any() or torch.isinf(features).any()):
                features = F.normalize(features, p=2, dim=1)

                with torch.no_grad():
                    teacher_probs = F.softmax(teacher_logits, dim=1)
                    max_probs, pseudo_labels = teacher_probs.max(dim=1)
                    low_conf_mask = max_probs < self.confidence_threshold
                    pseudo_labels[low_conf_mask] = 255

                pseudo_labels_resized = self.resize_mask(pseudo_labels, (Hf, Wf))

                bg_mask = (pseudo_labels_resized == 0)
                if bg_mask.sum() > 0:
                    feat_flat = features.permute(0, 2, 3, 1).reshape(-1, C)
                    mask_flat = bg_mask.view(-1).bool()
                    bg_features = feat_flat[mask_flat]

                    if bg_features.size(0) > 256:
                        indices = torch.randperm(bg_features.size(0), device=device)[:256]
                        bg_features = bg_features[indices]

                    if not torch.isnan(bg_features).any():
                        self.negative_buffer_unlabeled.update(bg_features)

                buffer = self.negative_buffer_unlabeled.get_buffer()
                if buffer is not None and len(self.negative_buffer_unlabeled) >= self.min_buffer_size:
                    contrastive_loss = self.contrastive_loss(features, pseudo_labels_resized, buffer)

        contrastive_loss = torch.clamp(contrastive_loss, min=0.0, max=1.0)  # ✅ 确保裁剪

        # ========== 3. 一致性损失 ==========
        consistency_loss = torch.tensor(0.0, device=device, requires_grad=True)

        if compute_consistency:
            if student_logits_weak is not None:
                with torch.no_grad():
                    teacher_probs = F.softmax(teacher_logits, dim=1)
                    max_probs, _ = teacher_probs.max(dim=1)
                    conf_mask = (max_probs > self.confidence_threshold).float()
                consistency_loss = self.consistency_loss(student_logits, student_logits_weak, conf_mask)
            else:
                with torch.no_grad():
                    teacher_probs = F.softmax(teacher_logits, dim=1)
                    max_probs, _ = teacher_probs.max(dim=1)
                    conf_mask = (max_probs > self.confidence_threshold).float()
                consistency_loss = self.consistency_loss(student_logits, teacher_logits.detach(), conf_mask)

        consistency_loss = torch.clamp(consistency_loss, min=0.0, max=1.0)  # ✅ 确保裁剪

        return {
            "rcps_loss": rcps_loss,
            "contrastive_loss": contrastive_loss,
            "consistency_loss": consistency_loss
        }

    def clear_buffers(self):
        self.negative_buffer_labeled.clear()
        self.negative_buffer_unlabeled.clear()
